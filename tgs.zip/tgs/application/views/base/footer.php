  <div class="footer-bot py-5 text-center">
    <div class="container">
      <div class="logo2">
        <h2>
          <a href="index.html">
            <span>G</span>o -
            <span>B</span>engkel
          </a>
        </h2>
        <small class="text-white" style="font-style: italic;">Layanan service mobil online</small>

        <p class="text-white">Untuk memenuhi tugas matakuliah Web Programming 2</p>
      </div>
      <!-- social icons -->
      <div class="agileinfo_social_icons my-4">
        <ul class="agileits_social_list list-unstyled">
          <li>
            <a href="#" class="w3_agile_facebook">
              <i class="fab fa-facebook-f"></i>
            </a>
          </li>
          <li class="mx-2">
            <a href="#" class="agile_twitter">
              <i class="fab fa-twitter"></i>
            </a>
          </li>
          <li>
            <a href="#" class="w3_agile_dribble">
              <i class="fab fa-dribbble"></i>
            </a>
          </li>
          <li class="ml-2">
            <a href="#" class="w3_agile_google">
              <i class="fab fa-google-plus-g"></i>
            </a>
          </li>
        </ul>
      </div>
      <!-- social icons -->
      <!-- copyright -->
      <p class="copyright-w3ls"> &copy; <?php 
        echo date("Y");
       ?> Go-Bengkel. All Rights Reserved | Design by
        <a target="blank" href="http://w3layouts.com/"> W3layouts</a>
      </p>
      <!-- //copyright -->
    </div>
  </div>