<head>
  <title>Go-Bengkel | Layanan service mobil</title>
  <!-- Meta tag Keywords -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="UTF-8" />
  <meta name="keywords" content="Car Services Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"
  />
  <script>
    addEventListener("load", function () {
      setTimeout(hideURLbar, 0);
    }, false);

    function hideURLbar() {
      window.scrollTo(0, 1);
    }
  </script>
  <!--// Meta tag Keywords -->

  <script type="text/javascript">
    var main_url = "<?= str_replace("index.php", '', site_url()) ?>";
  </script>
  <!-- Custom-Files -->
  <link rel="stylesheet" href="assets/css/bootstrap.css">
  <!-- Bootstrap-Core-CSS -->
  <link href="assets/css/JiSlider.css" rel="stylesheet">
  <!-- //banner-slider -->
  <link rel="stylesheet" href="assets/css/smoothbox.css" type='text/css' media="all" />
  <!-- gallery lightbox -->
  <link rel="stylesheet" href="assets/css/style.css" type="text/css" media="all" />
  <link rel="stylesheet" href="assets/css/custom.css" type="text/css" media="all" />
  <!-- Style-CSS -->
  <link rel="stylesheet" href="assets/css/fontawesome-all.css">
  <!-- Font-Awesome-Icons-CSS -->
  <!-- //Custom-Files -->

  <!-- Web-Fonts -->
  <link href="//fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&amp;subset=latin-ext"
      rel="stylesheet">
  <link href="//fonts.googleapis.com/css?family=Dr+Sugiyama&amp;subset=latin-ext" rel="stylesheet">
  <!-- //Web-Fonts -->

</head>