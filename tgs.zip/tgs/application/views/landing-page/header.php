    <header>
      <div class="container-fluid">
        <div class="row header-w3ls-top pt-lg-5 pt-md-4 pt-3 px-lg-5 px-3">
          <div class="col-xl-10 col-md-9 col-sm-8 col-6 logo">
            <h1>
              <a href="index.html">
                <span>G</span>O -
                <span>B</span>ENGKEL
              </a>
            </h1>
          </div>
          <div class="col-xl-2 col-md-3 col-sm-4 col-6 menu-agile text-center">
            <a href="#menu" id="toggle">
              <span></span>
            </a>
            <div id="menu" class="menustyles">
              <ul class="list-unstyled">
                <li>
                  <a href="#" data-toggle="modal" data-target="#masuk">Masuk / Daftar</a>
                </li>
                <li>
                  <a href="#layanan" class="scroll">Layanan</a>
                </li>
                <li>
                  <a href="#sparepart" class="scroll">Sparepart</a>
                </li>
                <li>
                  <a href="#cara_kerja" class="scroll">Cara Kerja</a>
                </li>
                <li>
                  <a href="#kontak" class="scroll">Kontak</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </header>