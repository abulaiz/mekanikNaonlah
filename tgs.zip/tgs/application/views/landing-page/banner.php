    <div class="banner-silder">
      <div id="JiSlider" class="jislider">
        <ul>
          <li>
            <div class="banner-top banner-top1">
              <div class="container">
                <div class="banner-info">
                  <h3 class="name text-white text-uppercase text-center">
                    <span class="name-part w3l-text1">service</span>
                    <span class="name-part w3l-text2">mobil</span>
                    <span class="name-part w3l-text3">
                      <label>online</label> terpercaya</span>
                  </h3>
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="banner-top banner-top2 delay-show" style="display: none;">
              <div class="container">
                <div class="banner-info">
                  <h3 class="name text-white text-uppercase text-center">
                    <span class="name-part w3l-text1">dukungan</span>
                    <span class="name-part w3l-text2">teknisi</span>
                    <span class="name-part w3l-text3">
                      <label>terbaik</label> dari kami</span>
                  </h3>
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="banner-top banner-top3 delay-show" style="display: none;">
              <div class="container">
                <div class="banner-info">
                  <h3 class="name text-white text-uppercase text-center">
                    <span class="name-part w3l-text1">service</span>
                    <span class="name-part w3l-text2">mudah</span>
                    <span class="name-part w3l-text3">dan
                      <label>fleksibel</label> dengan waktu</span>
                  </h3>
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="banner-top banner-top4 delay-show" style="display: none;">
              <div class="container">
                <div class="banner-info">
                  <h3 class="name text-white text-uppercase text-center">
                    <span class="name-part w3l-text1">teknisi</span>
                    <span class="name-part w3l-text2">kami</span>
                    <span class="name-part w3l-text3">datang
                      <label>ke</label> rumah anda</span>
                  </h3>
                </div>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>